# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from time import time, strftime, localtime


from django.shortcuts import render, HttpResponse, redirect

# Create your views here.
def index(request):

	return render(request, 'SessionWords_app/index.html')

def add(request):

	if not 'data' in request.session:
		request.session['data'] = []

	if request.method == 'POST':
	
		context = {}
		context['word'] = request.POST['word']

		if 'color' in request.POST:
			context['color'] = request.POST['color']

		else:
			context['color'] = 'black'

		if 'font' in request.POST:
			context['font'] = request.POST['font']

		else:
			context['font'] = "smallFont"

		context['time'] = strftime("%I:%M %p, %B %d, %Y", localtime())

		request.session['data'] += [context] 

		# request.session['data']. append(context) WHY CANT I USE APPEND?!

		print request.session['data']

		print len(request.session['data'])

		print type(request.session['data'])


	return redirect("/session_words")

def clear(request):

	if 'data' in request.session:
		request.session['data'] = []
	

	return redirect("/session_words")